// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class Main {
    public static void main(String[] args) {
        // Press Alt+Enter with your caret at the highlighted text to see how
        // IntelliJ IDEA suggests fixing it.

        System.setProperty("webdriver.chrome.driver","C:\\Selenium Jars and drivers\\drivers\\chromedriver-win64\\chromedriver-win64\\chromedriver.exe.");
        // Press Shift+F10 or click the green arrow button in the gutter to run the code.
        WebDriver driver=new ChromeDriver();
        //driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(60));

        driver.navigate().to("https://petstore.octoperf.com/actions/Account.action?signonForm=");
        //driver.findElement(By.id("username")).clear();
        driver.findElement(By.name("username")).sendKeys("Rashmi");
        driver.findElement(By.name("password")).clear();
        driver.findElement(By.name("password")).sendKeys("rash1990");
        driver.findElement(By.name("signon")).click();
        WebDriverWait w=new WebDriverWait(driver, Duration.ofSeconds(30));
        w.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id=\"SidebarContent\"]/a[2]/img")));


        driver.findElement(By.xpath("//*[@id=\"SidebarContent\"]/a[2]/img")).click();

        driver.findElement(By.xpath("//*[@id=\"Catalog\"]/table/tbody/tr[5]/td[1]/a")).click();

        driver.findElement(By.xpath("//*[@id=\"Catalog\"]/table/tbody/tr[2]/td[5]/a")).click();

        driver.findElement(By.xpath("//*[@id=\"Cart\"]/a")).click();

        driver.findElement(By.xpath("//*[@id=\"Catalog\"]/form/input")).click();

        driver.findElement(By.xpath("//*[@id=\"Catalog\"]/a")).click();

        driver.findElement(By.xpath("//*[@id=\"MenuContent\"]/a[2]")).click();
        driver.close();
        }
    }
